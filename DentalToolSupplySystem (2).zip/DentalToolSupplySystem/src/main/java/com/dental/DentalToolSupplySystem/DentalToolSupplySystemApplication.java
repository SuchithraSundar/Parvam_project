package com.dental.DentalToolSupplySystem;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DentalToolSupplySystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(DentalToolSupplySystemApplication.class, args);
	}

}
