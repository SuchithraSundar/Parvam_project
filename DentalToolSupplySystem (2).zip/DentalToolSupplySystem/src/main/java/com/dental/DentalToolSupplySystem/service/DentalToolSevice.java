package com.dental.DentalToolSupplySystem.service;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.dental.DentalToolSupplySystem.dto.DentalToolDTO;
import com.dental.DentalToolSupplySystem.model.DentalTool;
import com.dental.DentalToolSupplySystem.repository.DentalToolRepository;


@Service
public class DentalToolSevice {

		private DentalToolRepository dentaltoolRepository;
		private PasswordEncoder passwordEncoder;
		
		public DentalToolSevice(DentalToolRepository dentaltoolRepository, PasswordEncoder passwordEncoder) {
			super();
			this.dentaltoolRepository = dentaltoolRepository;
			this.passwordEncoder = passwordEncoder;
		}
		
		public void storeUser(DentalToolDTO dentaltoolDTO)
		{
			DentalTool dental = new DentalTool();

			dental.setFirstname(dentaltoolDTO.getFirstname());
			dental.setLastname(dentaltoolDTO.getLastname());
			dental.setEmail(dentaltoolDTO.getEmail());
			dental.setDob(dentaltoolDTO.getDob());
			dental.setGender(dentaltoolDTO.getGender());
			dental.setPassword(passwordEncoder.encode(dentaltoolDTO.getPassword()));
			dental.setConfirmpassword(dentaltoolDTO.getConfirmpassword());
			dental.setRole("ROLE_USER");
			
			dentaltoolRepository.save(dental);
		}

		
}
